import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { NgxDatatableModule } from '@swimlane/ngx-datatable'; 
import { FormsModule } from '@angular/forms';  
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { ToastrModule } from 'ngx-toastr';
import { NavComponent } from './nav/nav.component';
import { Sidenav } from './sidenav/sidenav.component';
import { FooterComponent } from './footer/footer.component';
import { ContainerComponent } from './container/container.component';
import { WelcomeSectionComponent } from './welcome-section/welcome-section.component';
import { ToasterComponent } from './toaster/toaster.component';
import { NotificationService } from './notification.service';
import { NgxDatatableComponent } from './ngx-datatable/ngx-datatable.component';
import { PipesComponent } from './pipes/pipes.component';

@NgModule({
  declarations: [
    AppComponent,
    NavComponent,
    Sidenav,
    FooterComponent,
    ContainerComponent,
    WelcomeSectionComponent,
    ToasterComponent,
    NgxDatatableComponent,
    PipesComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    BrowserAnimationsModule,
    ToastrModule.forRoot(),
    FormsModule, 
    NgxDatatableModule
  ],
  providers: [NotificationService],
  bootstrap: [AppComponent]
})
export class AppModule { }
