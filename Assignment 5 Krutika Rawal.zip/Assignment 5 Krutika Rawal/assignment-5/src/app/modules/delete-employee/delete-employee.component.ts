import { Component,EventEmitter,Input,Output } from '@angular/core';
import { FormControl, FormGroup} from '@angular/forms';

import { EmployeeService } from 'src/app/services/employee.service';
import { ToastrService } from 'ngx-toastr';
@Component({
  selector: 'app-delete-employee',
  templateUrl: './delete-employee.component.html',
  styleUrls: ['./delete-employee.component.scss']
})
export class DeleteEmployeeComponent {
  @Input() employee : any;
  @Output() close = new EventEmitter();

  constructor(private toastrService: ToastrService, 
    private employeeService: EmployeeService) { }

    public onClose(): void {
      this.close.emit();
    }

    public delete(): void {
      this.employeeService.deleteEmployee(this.employee.id).subscribe((response: any)=> {
        this.toastrService.success("Employee deleted successfully", "Success");
        this.onClose();
    }, (error: any)=> {
      this.toastrService.error("Error deleting employee", "Error");
    })
    }
  
}
