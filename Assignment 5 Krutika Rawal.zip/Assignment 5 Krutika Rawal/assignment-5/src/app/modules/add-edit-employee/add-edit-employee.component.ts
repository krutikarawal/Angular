import { Component, EventEmitter, Input, Output } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { ToastrService } from 'ngx-toastr';
import { EmployeeService } from 'src/app/services/employee.service';

@Component({
  selector: 'add-edit-employee',
  templateUrl: './add-edit-employee.component.html',
})
export class AddEditEmployeeComponent {
  @Input() employee: any;
  @Output() close = new EventEmitter();

  public employeeForm = new FormGroup({
    firstName: new FormControl('',[Validators.required,Validators.maxLength(250)]),
    lastName: new FormControl('', [Validators.required, Validators.maxLength(250)]),
    dob: new FormControl('', [Validators.required]), 
    gender: new FormControl('', [Validators.required]), 
    email: new FormControl('', [Validators.required,Validators.email, Validators.maxLength(250)]), 
    company: new FormControl('', [Validators.required,Validators.maxLength(250)]), 
    qualification: new FormControl('', [Validators.required, Validators.maxLength(250)]), 
    experience: new FormControl('', [Validators.required,Validators.maxLength(250)]), 
    package: new FormControl('', [Validators.required,Validators.maxLength(250)]), 
  });

  constructor(
    private employeeService: EmployeeService,
    private toastrService: ToastrService
  ) {}

  ngOnInit() {
    if (this.employee) {
      this.employeeForm.patchValue(this.employee);
    }
  }

  public onClose() {
    this.close.emit();
  }

  public save(): void {
    let payload = this.assignValueToModel();
    if (!this.employee) {
      this.addEmployee(payload);
    } else {
      this.updateEmployee(payload);
    }
  }

  public addEmployee(payload: any): void {
    this.employeeService.addEmployee(payload).subscribe(
      (response: any) => {
        this.toastrService.success('Employee added Successfully', 'Success');
        this.onClose();
      },
      (error: any) => {
        this.toastrService.error('Error adding record', 'Error');
      }
    );
  }

  public updateEmployee(payload: any): void {
    this.employeeService.updateEmployee(payload).subscribe(
      (response: any) => {
        this.toastrService.success('Employee updated Successfully', 'Success');
        this.onClose();
      },
      (error: any) => {
        this.toastrService.error('Error updating record', 'Error');
      }
    );
  }

  public checkIfControlValid(controlName: string): any {
    return this.employeeForm.get(controlName) ?.invalid &&
    this.employeeForm.get(controlName) ?.errors &&
      (this.employeeForm.get(controlName)?.dirty || this.employeeForm.get(controlName)?.touched);
  }

  public checkControlHasError(controlName: string, error: string): any {
    return  this.employeeForm.get(controlName)?.hasError(error);
  }

  private assignValueToModel(): any {
    let employee = {
      id: this.employee ? this.employee.id : 0,
      firstName: this.employeeForm.get('firstName')?.value,
      lastName: this.employeeForm.get('lastName')?.value,
      dob: this.employeeForm.get('dob')?.value,
      gender: this.employeeForm.get('gender')?.value, 
      email: this.employeeForm.get('email')?.value, 
      company:this.employeeForm.get('company')?.value,
      qualification: this.employeeForm.get('qualification')?.value, 
      experience: this.employeeForm.get('experience')?.value, 
      package: this.employeeForm.get('package')?.value, 
    };
    return employee;
  }
}
