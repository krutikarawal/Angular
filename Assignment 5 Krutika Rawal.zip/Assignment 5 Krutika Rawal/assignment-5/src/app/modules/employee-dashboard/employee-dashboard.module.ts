import { NgModule } from '@angular/core';
import { AppRoutingModule } from 'src/app/app-routing.module'; 
import { FormsModule, ReactiveFormsModule}   from '@angular/forms';  
import { EmployeeDashboardComponent } from './employee-dashboard.component';
import { NavbarComponent } from '../navbar/navbar.component';
import { HttpClientModule } from '@angular/common/http';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations'
import { EmployeeComponent } from '../employee/employee.component';
import { EmployeeService } from 'src/app/services/employee.service';
import { NgxDatatableModule } from '@swimlane/ngx-datatable';
import { AddEditEmployeeComponent } from '../add-edit-employee/add-edit-employee.component';
import { ModalModule } from 'ngx-bootstrap/modal';
import { ToastrModule } from 'ngx-toastr';
import { DeleteEmployeeComponent } from '../delete-employee/delete-employee.component'; 
import { FooterComponent } from '../footer/footer.component';
import { RouterModule, Routes } from '@angular/router';
import { AuthGuard } from 'src/app/helper/auth.gaurd';
import { CommonModule } from '@angular/common';

const dashboardRoutes: Routes = [
    {
        path: 'dashboard', 
        component: EmployeeDashboardComponent,
        canActivate:[AuthGuard]
    }
]
@NgModule({
  declarations: [
    EmployeeDashboardComponent,
    NavbarComponent,
    EmployeeComponent,
    AddEditEmployeeComponent,
    DeleteEmployeeComponent,
    FooterComponent, 
  ],
  imports: [
    RouterModule.forChild(dashboardRoutes),
    HttpClientModule,
    AppRoutingModule,
    FormsModule,
    BrowserAnimationsModule,
    NgxDatatableModule,
    ModalModule.forRoot(),
    ReactiveFormsModule,
    ToastrModule.forRoot(),
    CommonModule 
  ],
  providers: [EmployeeService],
  bootstrap: [],
  exports: [RouterModule]
})
export class EmployeeDashboardModule { }
