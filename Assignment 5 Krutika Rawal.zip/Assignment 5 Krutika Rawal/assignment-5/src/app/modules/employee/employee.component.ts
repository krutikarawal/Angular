import { Component } from '@angular/core';  
import { EmployeeService } from 'src/app/services/employee.service';
import {BsModalRef,BsModalService} from 'ngx-bootstrap/modal'
import { AddEditEmployeeComponent } from '../add-edit-employee/add-edit-employee.component';
import { ToastrService } from 'ngx-toastr';
import { DeleteEmployeeComponent } from '../delete-employee/delete-employee.component';
@Component({
  selector: 'app-employee',
  templateUrl: './employee.component.html',
  styleUrls: ['./employee.component.scss']
})

export class EmployeeComponent {  

  public totalCount: number = 0;  
  public employees: any[] = [];
  public addEditEmployeeModal!: BsModalRef;
  public deleteEmployeeModel!: BsModalRef;

  constructor( 
    private EmployeeService: EmployeeService, 
    private modalService: BsModalService,
    private toastrService: ToastrService
    ) { }

  ngOnInit() {  
   this.loadEmployees();
  }  

  private loadEmployees(): void {
    this.EmployeeService.getEmployees().subscribe((response: any) => {
      this.employees = response;
      this.totalCount =   this.employees.length;
    }, (error: any) => {
      this.toastrService.error("error loading Employees list","error")
    })  
  }

  public openAddEditEmployeeModal(employee: any = null) : void {
    this.addEditEmployeeModal = this.modalService.show(AddEditEmployeeComponent,{
      initialState:{employee : employee},
      class:'modal-lg',
      ignoreBackdropClick: true
    });

    this.addEditEmployeeModal.content.close.subscribe(() => {
      this.addEditEmployeeModal.hide();
      this.loadEmployees();
    });
  }

  public openDeleteEmployeeModal(employee: any): void {
    this.deleteEmployeeModel = this.modalService.show(DeleteEmployeeComponent, {
      initialState: {employee : employee}, class: "model-lg", ignoreBackdropClick: true
    });
    this.deleteEmployeeModel.content.close.subscribe(()=> {
      this.deleteEmployeeModel.hide();
      this.loadEmployees();
    })
  }

}  