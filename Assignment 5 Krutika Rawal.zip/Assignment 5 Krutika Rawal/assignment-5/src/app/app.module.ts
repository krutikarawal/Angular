import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { HttpClientModule } from '@angular/common/http';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations'
import { EmployeeService } from './services/employee.service';
import { NgxDatatableModule } from '@swimlane/ngx-datatable';
import { ModalModule } from 'ngx-bootstrap/modal';
import { ReactiveFormsModule } from '@angular/forms';
import { ToastrModule } from 'ngx-toastr';
import { LoginComponent } from './modules/login/login.component';
import { EmployeeDashboardModule } from './modules/employee-dashboard/employee-dashboard.module';
import { RouterModule, Routes } from '@angular/router';

const employeeDashboardModule = () => import('./modules/employee-dashboard/employee-dashboard.module').then(x => x.EmployeeDashboardModule);

const appRoutes: Routes = [
  {path:'' , component: LoginComponent},
  {path: 'login', component: LoginComponent},
  {path:'dashboard',children:[{path: '', loadChildren: employeeDashboardModule}] },
  {path:'**', component:LoginComponent},
]
@NgModule({
  declarations: [
    AppComponent,
    LoginComponent
  ],
  imports: [
    RouterModule.forRoot(appRoutes),
    BrowserModule,
    AppRoutingModule,
    HttpClientModule,
    EmployeeDashboardModule,
    BrowserAnimationsModule,
    NgxDatatableModule,
    ModalModule.forRoot(),
    ReactiveFormsModule,
    ToastrModule.forRoot() 
  ],
  providers: [EmployeeService],
  bootstrap: [AppComponent]
})
export class AppModule { }
