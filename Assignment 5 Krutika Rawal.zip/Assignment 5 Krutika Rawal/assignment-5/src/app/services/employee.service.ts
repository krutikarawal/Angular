import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
@Injectable({
  providedIn: 'root'
})
export class EmployeeService {
  constructor(public httpClient: HttpClient) { }
  public res :any = []

  public getEmployees() { 
    return this.httpClient.get(`http://localhost:3000/employees`);
  }  

  public addEmployee(employee: any ): any {
    return this.httpClient.post(`http://localhost:3000/employees`,employee);
  }

  public updateEmployee(employee: any ): any {
    return this.httpClient.put(` http://localhost:3000/employees/${employee.id}`,employee);
  }

  public deleteEmployee(employeeId: any): any {
    return this.httpClient.delete(` http://localhost:3000/employees/${employeeId}`);
  }
}
