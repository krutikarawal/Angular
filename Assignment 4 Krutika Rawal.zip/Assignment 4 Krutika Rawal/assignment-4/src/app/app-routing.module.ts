import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { WelcomeSectionComponent } from './welcome-section/welcome-section.component';
import { NgxDatatableComponent } from './ngx-datatable/ngx-datatable.component';
import { ToasterComponent } from './toaster/toaster.component';
import { PipesComponent } from './pipes/pipes.component';

const routes: Routes = [
  { path: 'welcome-section', component: WelcomeSectionComponent},
  { path: 'datatable', component: NgxDatatableComponent},
  { path: 'toaster', component: ToasterComponent},
  { path: 'pipe', component:PipesComponent}
];
@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
