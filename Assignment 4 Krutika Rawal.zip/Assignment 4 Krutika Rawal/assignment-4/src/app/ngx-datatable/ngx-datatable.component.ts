import { Component,OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { NgxDatatableService } from '../ngx-datatable.service';

@Component({
  selector: 'app-ngx-datatable',
  templateUrl: './ngx-datatable.component.html',
  styleUrls: ['./ngx-datatable.component.scss']
})
export class NgxDatatableComponent implements OnInit{

  rows: any = [];
  totalCount: number = 0;
  closeResult: string = '';
  dataParams: any = {
    page_num: '',
    page_size: ''
  };

  constructor (private ngxDatatableService: NgxDatatableService) { }

  ngOnInit(): void {
    this.dataParams.page_num = 1;
    this.dataParams.page_size = 20;
    this.getAllHeroList();
  }

  getAllHeroList() {
    this.rows = this. ngxDatatableService.hero_pages;
    this.totalCount = this. ngxDatatableService.total_count;
  }
}
