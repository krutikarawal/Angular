import { Component } from '@angular/core';

@Component({
  selector: 'app-pipes',
  templateUrl: './pipes.component.html',
  styleUrls: ['./pipes.component.scss']
})
export class PipesComponent {
  public name = 'Krutika';
  public message = ' Welcome to world';
  public person = {
    "firstName": "John",
    "lastName" : "Doe"
  }

  public date = new Date();
  constructor () {}
}
