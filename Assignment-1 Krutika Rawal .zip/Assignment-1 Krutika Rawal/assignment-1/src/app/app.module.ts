import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { FormsModule } from "@angular/forms";
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { ContainerComponent } from './container/container.component';
import { NavComponent } from './nav/nav.component';
import { Sidenav } from './sidenav/sidenav.component';
import { FooterComponent } from './footer/footer.component';
import { WelcomeSectionComponent } from './welcome-section/welcome-section.component';
import { EventHandlerComponent } from './event-handler/event-handler.component';
import { ArithmeticComponent } from './arithmetic/arithmetic.component';
@NgModule({
  declarations: [
    AppComponent,
    ContainerComponent,
    NavComponent,
    Sidenav,
    WelcomeSectionComponent,
    EventHandlerComponent,
    ArithmeticComponent,
    FooterComponent
  ],
  imports: [
    BrowserModule,
    FormsModule,
    AppRoutingModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
