import { Component, OnInit } from "@angular/core";
import { NgModel } from "@angular/forms";

@Component({
  selector: "app-event-handler",
  templateUrl: "event-handler.component.html",
  styleUrls: ["./event-handler.component.scss"]
})
export class EventHandlerComponent implements OnInit {
  constructor() { }
  ngOnInit(): void {

  }
  // demonstration of access specifier & two way data binding 
  public name: string = " ";

  public greet(): void {
    alert("Thankyou" + this.name +" for your feedback");
    console.log(this.name)
  };
}
  