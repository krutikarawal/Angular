import { Component } from '@angular/core';

@Component({
  selector: 'app-arithmetic',
  templateUrl: './arithmetic.component.html',
  styleUrls: ['./arithmetic.component.scss']
})
export class ArithmeticComponent {

  public sample = "";
  public clickMessage = "";
  public name = "";
  public firstnumber = 0;
  public secondnumber = 0;
  public result = 0;

  onAdd() {
    this.result = this.firstnumber + this.secondnumber;
  }

  onSubtract() {
    this.result = this.firstnumber - this.secondnumber;
  }

  onMultiply() {
    this.result = this.firstnumber * this.secondnumber;
  }

  onDivide() {
    this.result = this.firstnumber / this.secondnumber;
  }
  

}