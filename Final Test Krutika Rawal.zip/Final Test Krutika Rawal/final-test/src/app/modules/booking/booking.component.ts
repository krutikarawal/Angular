import { Component, OnInit } from '@angular/core';
import { SeatBookingService } from '../shared/services/seat-booking.service'; 
import { ToastrService } from 'ngx-toastr';
import { BsModalRef, BsModalService } from 'ngx-bootstrap/modal';
import { AddEditTicketComponent } from '../add-edit-ticket/add-edit-ticket.component';
import { DeleteBookingComponent } from '../delete-booking/delete-booking.component';
@Component({
  selector: 'app-booking',
  templateUrl: './booking.component.html',
  styleUrls: ['./booking.component.scss']
})
export class BookingComponent {

  public seatBookings: any[] = [];
  public totalCount: number = 0;  
  public addEditBookingModal!: BsModalRef;
  public deleteBookingModel!: BsModalRef;

  constructor(private seatBookingService: SeatBookingService,
    private toastrService: ToastrService,
    private modalService: BsModalService) {}

  ngOnInit(): void {
    this.getSeatBookings();
  }

  private getSeatBookings(): void {
    this.seatBookingService.getSeatBookings().subscribe((response: any[]) => {
      this.seatBookings = response;
      this.totalCount =   this.seatBookings.length;
    },(error: any) => {
      this.toastrService.error("error loading Booking list","error")
    });
  }

  openAddEditBookingModal(booking: any = null): void {
    this.addEditBookingModal = this.modalService.show(AddEditTicketComponent, {
      initialState: { booking: booking },
      class: 'modal-lg',
      ignoreBackdropClick: true
    });

    this.addEditBookingModal.content.close.subscribe(() => {
      this.addEditBookingModal.hide();
      this.getSeatBookings();
    });
  }

  public openDeleteBookingModal(employee: any): void {
    this.deleteBookingModel = this.modalService.show(DeleteBookingComponent, {
      initialState: {employee : employee}, class: "model-lg", ignoreBackdropClick: true
    });
    this.deleteBookingModel.content.close.subscribe(()=> {
      this.deleteBookingModel.hide();
      this.getSeatBookings();
    })
  }

}
