import { Component } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-navbar',
  templateUrl: './navbar.component.html',
  styleUrls: ['./navbar.component.scss']
})
export class NavbarComponent {
  constructor(private router: Router) { }

  /**
 * To logout the system
 * check if the userName value in the localStorage is null
 * If the userName is null, it means the user is logged in
 * If the userName is not null, it means the user is still logged in
 */
  public logOut(): void {
    localStorage.removeItem('userName');
    this.router.navigate(['/login'])
  }
}
