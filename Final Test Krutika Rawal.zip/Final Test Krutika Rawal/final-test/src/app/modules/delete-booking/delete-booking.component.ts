import { Component,EventEmitter,Input,Output } from '@angular/core';
import { FormControl, FormGroup} from '@angular/forms';

import { SeatBookingService } from '../shared/services/seat-booking.service';
import { ToastrService } from 'ngx-toastr';
@Component({
  selector: 'app-delete-booking',
  templateUrl: './delete-booking.component.html',
  styleUrls: ['./delete-booking.component.scss']
})
export class DeleteBookingComponent {
  @Input() employee : any;
  @Output() close = new EventEmitter();

  constructor(private toastrService: ToastrService, 
    private bookingService: SeatBookingService) { }

    public onClose(): void {
      this.close.emit();
    }

    public delete(): void {
      this.bookingService.deleteBooking(this.employee.id).subscribe((response: any)=> {
        this.toastrService.success("Booking deleted successfully", "Success");
        this.onClose();
    }, (error: any)=> {
      this.toastrService.error("Error deleting Booking", "Error");
    })
    }
  
}
