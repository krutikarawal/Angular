import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { ToastrService } from 'ngx-toastr';
import { SeatBookingService } from '../shared/services/seat-booking.service';
import { BusService } from '../shared/services/busService .service';

@Component({
  selector: 'add-edit-ticket',
  templateUrl: './add-edit-ticket.component.html',
})

export class AddEditTicketComponent {
  @Input() booking: any;
  @Output() close = new EventEmitter();

  public busNumbers: string[] = [];
  public seatNumbers: string[] = [];
  public isSeatAlreadyBooked: boolean = false;
  public selectedBusNumber: string = '';
  public seats: any = [];
  public currentDate: Date = new Date();

  // Form Validation
  public bookingForm = new FormGroup({
    id: new FormControl(0),
    busNo: new FormControl('', [Validators.required]),
    seatNo: new FormControl('', [Validators.required]),
    bookingDate: new FormControl('', [Validators.required]),
    personalDetails: new FormGroup({
      firstName: new FormControl('', [Validators.required, Validators.maxLength(250)]),
      lastName: new FormControl('', [Validators.required, Validators.maxLength(250)]),
      email: new FormControl('', [Validators.required, Validators.email, Validators.maxLength(250)]),
      phone: new FormControl('', [Validators.required, Validators.pattern(/^(\+\d{1,3}[- ]?)?\d{10}$/)]),
    }),
  });

  constructor(
    private seatBookingService: SeatBookingService,
    private toastrService: ToastrService,
    private busService: BusService,
  ) { }

  ngOnInit() {
    this.getBusNumbers();
    if (this.booking) {
      this.bookingForm.patchValue(this.booking);
    }
  }

  // Function for getting the Bus
  public getBusNumbers(): void {
    this.busService.getBusNumbers().subscribe((response: any) => {
      this.busNumbers = response;
      this.generateSeatNumbers();
    }, (error: any) => {
      this.toastrService.error('Error fetching bus numbers', 'Error');
    });
  }

  // Generate the Dynamic seat number
  public generateSeatNumbers(): void {
    this.seatNumbers = [];
    for (let i = 1; i <= 10; i++) {
      this.seatNumbers.push("S" + i);
    }
  }

  public checkIfSeatBooked(): void {
    let busNo = this.bookingForm.get("busNo")?.value;
    let seatNo = this.bookingForm.get("seatNo")?.value;
    let bookingDate = new Date(this.bookingForm.get("bookingDate")?.value ?? "").toDateString();

    this.seatBookingService.getSeatBookings().subscribe(
      (response: any) => {
        let existingBookingIndex = response.findIndex((x: any) => x.busNo === busNo && x.seatNo === seatNo);

        if (existingBookingIndex !== -1) {
          let existingBooking = response[existingBookingIndex];
          let existingBookingDate = new Date(existingBooking.bookingDate).toDateString(); // Convert to date and remove time

          if (existingBookingDate === bookingDate) {
            // Seat is already booked for the same date
            this.isSeatAlreadyBooked = true;
            this.toastrService.error("Seat is already booked for the date", "Error");
          } else {
            // Seat is booked for a different date, allow the user to add the record
            this.isSeatAlreadyBooked = false;
          }
        } else {
          // Seat is not booked, allow the user to add the record
          this.isSeatAlreadyBooked = false;
        }
      },
      (error: any) => {
        // Handle specific error cases based on the error response from your API
        this.toastrService.error('Error booking record: ' + error.message, 'Error');
      }
    );
  }


  public onClose() {
    this.close.emit();
  }

  public save(): void {
    const payload = this.assignValueToModel();
    let selectedSeat: any = this.bookingForm.get('seatNo')?.value;
    let selectedDate: any = new Date(this.bookingForm.get('bookingDate')?.value ?? "").toDateString();

    this.seatBookingService.getSeatBookings().subscribe((response: any[]) => {
      let seatIndex = response.findIndex((seat) => seat.seatNo == selectedSeat && new Date(seat.bookingDate).toDateString() === selectedDate);

      if (seatIndex == -1) {
        if (!this.booking) {
          this.addBooking(payload);
        } else {
          this.updateBooking(payload);
        }
      } else {
        this.toastrService.error("Seat is already booked for the selected date", "Error");
      }
    });
  }

  public addBooking(payload: any): void {
    this.seatBookingService.addBooking(payload).subscribe(
      (response: any) => {
        this.toastrService.success('Booking added Successfully', 'Success');
        this.onClose();
      },
      (error: any) => {
        this.toastrService.error('Error adding record', 'Error');
      }
    );
  }

  public updateBooking(payload: any): void {
    this.seatBookingService.updateBooking(payload).subscribe(
      (response: any) => {
        this.toastrService.success('Booking updated Successfully', 'Success');
        this.onClose();
      },
      (error: any) => {
        this.toastrService.error('Error updating record', 'Error');
      }
    );
  }

  public checkIfControlValid(controlName: string): any {
    return this.bookingForm.get(controlName)?.invalid &&
      this.bookingForm.get(controlName)?.errors &&
      (this.bookingForm.get(controlName)?.dirty || this.bookingForm.get(controlName)?.touched);
  }

  public checkControlHasError(controlName: string, error: string): any {
    return this.bookingForm.get(controlName)?.hasError(error);
  }
  private assignValueToModel(): any {
    let booking = {
      id: this.bookingForm.get('id')?.value,
      busNo: this.bookingForm.get('busNo')?.value,
      seatNo: this.bookingForm.get('seatNo')?.value,
      bookingDate: this.bookingForm.get('bookingDate')?.value,
      personalDetails: {
        firstName: this.bookingForm.get('personalDetails.firstName')?.value,
        lastName: this.bookingForm.get('personalDetails.lastName')?.value,
        email: this.bookingForm.get('personalDetails.email')?.value,
        phone: this.bookingForm.get('personalDetails.phone')?.value
      }
    };
    return booking;
  }

}