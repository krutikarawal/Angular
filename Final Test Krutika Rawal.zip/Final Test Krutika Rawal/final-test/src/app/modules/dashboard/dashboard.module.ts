import { NgModule } from '@angular/core';
import { AppRoutingModule } from 'src/app/app-routing.module'; 
import { FormsModule, ReactiveFormsModule}   from '@angular/forms';  
import { DashboardComponent } from './dashboard.component';
import { NavbarComponent } from '../welcome/navbar/navbar.component';
import { WelcomeComponent } from '../welcome/welcome.component';
import { HttpClientModule } from '@angular/common/http';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations'
import { NgxDatatableModule } from '@swimlane/ngx-datatable';
import { ModalModule } from 'ngx-bootstrap/modal';
import { ToastrModule } from 'ngx-toastr';
import { FooterComponent } from '../footer/footer.component';
import { RouterModule, Routes } from '@angular/router';
import { AuthGuard } from '../shared/helper/auth.gaurd';
import { CommonModule } from '@angular/common';
import { BannerComponent } from '../welcome/banner/banner.component';
import { SidebarComponent } from '../welcome/sidebar/sidebar.component';
import { BookingComponent } from '../booking/booking.component';
import { AddEditTicketComponent } from '../add-edit-ticket/add-edit-ticket.component';

const dashboardRoutes: Routes = [
  {
      path: 'dashboard', 
      component: DashboardComponent,
      children: [
        {path: '', component:BannerComponent,canActivate:[AuthGuard]},
        {path: 'booking', component:BookingComponent,canActivate:[AuthGuard]},
      ],canActivate:[AuthGuard]
  }
]
@NgModule({
  declarations: [
    DashboardComponent,
    NavbarComponent,
    FooterComponent,
    WelcomeComponent,
    BannerComponent,
    SidebarComponent,
    BookingComponent,
    AddEditTicketComponent,
  ],
  imports :[
    RouterModule.forChild(dashboardRoutes),
    HttpClientModule,
    AppRoutingModule,
    FormsModule,
    BrowserAnimationsModule,
    NgxDatatableModule,
    ModalModule.forRoot(),
    ReactiveFormsModule,
    ToastrModule.forRoot(),
    CommonModule 
  ], 
  providers: [],
  bootstrap: [],
  exports: [RouterModule]
})
export class DashboardModule { }