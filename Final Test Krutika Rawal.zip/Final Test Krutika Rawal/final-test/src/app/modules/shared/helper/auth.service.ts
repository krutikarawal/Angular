import { Injectable } from "@angular/core";

@Injectable({
  providedIn: 'root'
})

export class AuthService {
  constructor() { }

  /**
   * This function checks if the user is logged in to the system.
   * It does so by checking if a userName exists in the localStorage
   * @returns Returns true if the userName exists, indicating that the user is logged in, otherwise
   */

  isLoggedIn() {
    return localStorage.getItem('userName') != null;
  }
}