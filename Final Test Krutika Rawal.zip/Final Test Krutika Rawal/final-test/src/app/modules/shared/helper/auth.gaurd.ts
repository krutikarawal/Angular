import { Injectable } from "@angular/core";
import { Router} from '@angular/router';
import { AuthService } from "./auth.service";

@Injectable({
  providedIn: 'root'
})

export class AuthGuard{

  constructor(
    private authService: AuthService,
    private route: Router
  ) {}

  /**
   * Checks if the user can visit the specific route.
   * @returns Returns true if the user is logged in and can vist the route, otherwise returns false
   */
  canActivate() {
    let isUserLoggedIn = localStorage.getItem("userName") !== null;
    if(isUserLoggedIn) {
      return true;
    }
    else{
      this.route.navigate(['/login']);
      return true;
    }
  }
}