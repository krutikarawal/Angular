import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class SeatBookingService {
  
  constructor(private httpClient: HttpClient) {}

  public res :any = []
  public getSeatBookings(): any {
    return this.httpClient.get(`http://localhost:3000/seatBookings`);
  }

  public addBooking(booking: any): any {
    return this.httpClient.post(`http://localhost:3000/seatBookings`, booking);
  }

  public updateBooking(booking: any ): any {
    return this.httpClient.put(`http://localhost:3000/seatBookings/${booking.id}`,booking);
  }

  public deleteBooking(bookingId: any): any {
    return this.httpClient.delete(` http://localhost:3000/seatBookings/${bookingId}`);
  }

}
