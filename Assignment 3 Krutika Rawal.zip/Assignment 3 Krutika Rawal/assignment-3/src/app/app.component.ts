import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})
export class AppComponent {
  title = 'Component Interaction';

  // Parent to Child
  public name = "Hello From Parent to child "

  public counter = 5;

  public increment() {
    this.counter++
  }

  public decrement() {
    this.counter--
  }

  // Child to parent receive from child component
  public dataChild: any;
  // Event handler for the child component's event
  public parentFunction(data: any): void {
    console.log(data);
    this.dataChild = data.message; // Access the 'message' property from the received data
  }

  // LifeCyle Hooks demonstration
  displayChild = false;
  toggle() {
    this.displayChild = !this.displayChild;
  }
  
}
