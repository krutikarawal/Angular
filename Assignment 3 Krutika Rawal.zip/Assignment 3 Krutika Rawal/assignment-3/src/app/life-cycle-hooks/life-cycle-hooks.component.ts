import { Component, OnChanges, SimpleChanges, OnInit, OnDestroy, AfterViewInit, AfterViewChecked, DoCheck } from '@angular/core';

@Component({
  selector: 'app-life-cycle-hooks',
  templateUrl: './life-cycle-hooks.component.html',
  styleUrls: ["./life-cycle-hooks.component.scss"]
})
export class LifeCycleHooksComponent implements OnChanges, OnInit, OnDestroy, AfterViewInit, AfterViewChecked, DoCheck {
  logMessages: string[] = [];

  constructor() {
    console.log('ChildComponent:Constructor')
    this.log('ChildComponent:Constructor');
  }

  ngOnChanges(changes: SimpleChanges): void {
    console.log('ChildComponent:OnChanges ' + JSON.stringify(changes))
    this.log('ChildComponent:OnChanges ' + JSON.stringify(changes));
  }

  ngOnInit(): void {
    console.log('ChildComponent:OnInit')
    this.log('ChildComponent:OnInit');
  }

  ngAfterViewInit(): void {
    console.log('ChildComponent:AfterViewInit');
  }

  ngAfterViewChecked(): void {
    console.log('ChildComponent:AfterViewChecked');
  }

  ngDoCheck(): void {
    console.log('ChildComponent:DoCheck')
    this.log('ChildComponent:DoCheck');
  }

  ngOnDestroy(): void {
    console.log('ChildComponent:OnDestroy');
  }

  private log(message: string): void {
    this.logMessages.push(message);
  }
}
