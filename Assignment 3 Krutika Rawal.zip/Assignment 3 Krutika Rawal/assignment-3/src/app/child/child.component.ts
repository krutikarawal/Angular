import { Component, Input,OnInit, Output, EventEmitter } from '@angular/core';

@Component({
  selector: 'app-child',
  templateUrl: './child.component.html',
  styleUrls: ['./child.component.scss']
})
export class ChildComponent {
  // Parent to Child Communication
  @Input() public parentData: any;
  @Input() public count: any;

  // Internal Communication
  public name = "Child to Parent "

  // Child to Parent Data Pass
  @Input() public dataChild: any;
  @Output() parentFunction: EventEmitter<any> = new EventEmitter()

  constructor() {}

  ngOnInit(): void {}

  sendData() {
    let message = {message:"Message From Child to Parent"}
    this.parentFunction.emit(message)
  }
}
